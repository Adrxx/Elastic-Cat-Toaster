/*:
 
 **Thank you for using my playground!**

 This right here is just the pulse of randomness, going on forever and ever...
 just like my passion for software and technology ❤️.
 
 I really had a lot of fun building it and I hope you had fun as using it.
 Feel free to use any art piece as your wallpaper if you want.
 
 *Roses are red...*
 
 *Violets are blue...*
 
 *I'm no good at rhymes...*
 
 *Toaster!*

 */
